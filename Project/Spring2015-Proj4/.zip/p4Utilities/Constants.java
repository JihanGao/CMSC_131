package p4Utilities;

public class Constants {
	public final static MyDouble BOUNDARY = new MyDouble(62831);
	public static int LIMIT = 31;
}
